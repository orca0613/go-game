from go_game import Go_game

__version__ = "0.1.0"
__author__ = "JS"

