min_size = 3
max_size = 19
EMPTY = "."
BLACK = "b"
WHITE = "w"